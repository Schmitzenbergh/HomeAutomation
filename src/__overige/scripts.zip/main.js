#!/usr/bin/env node

var init = require('./init.js'); 
init();





//light.setOn(4,true);
light.setAlert(4,"select");
sensor.getInfo(5,"buttonevent");
//light.getInfo(1,"manufacturername");
//light.getInfo(1,"modelid");
//light.getInfo(1,"name");
//light.getInfo(1,"sat");
//light.getInfo(1,"name");
//light.getInfo(1,"type");
//sensor.getInfo(5,"buttonevent");








