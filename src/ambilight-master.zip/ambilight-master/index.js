"use strict";

module.exports.AmbilightApi = require("./ambilight-api/index");
