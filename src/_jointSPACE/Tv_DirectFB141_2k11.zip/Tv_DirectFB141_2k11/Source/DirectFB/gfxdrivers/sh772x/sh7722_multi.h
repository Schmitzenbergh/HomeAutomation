#ifndef __SH7722__MULTI_H__
#define __SH7722__MULTI_H__

#include "sh7722_types.h"

#define SH7722_MULTI_SUPPORTED_OPTIONS  (DLOP_SRC_COLORKEY)

extern DisplayLayerFuncs sh7722MultiLayerFuncs;

#endif

