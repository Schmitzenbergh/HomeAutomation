
/*
 * (c) 2011 Koninklijke Philips Electronics N.V., All rights reserved
 * 
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Koninklijke Philips Electronics N.V. and is
 * confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Koninklijke Philips Electronics N.V.
 */


int idjsAmbiGetConfiguration = 0;
int idjsAmbiGetMode = 1;
int idjsAmbiGetNbrOfPixelsPerSide = 2;
int idjsAmbiGetPixel = 3;
int idjsAmbiGetPixelArray = 4;
int idjsAmbiGetRawPixel = 5;
int idjsAmbiGetRawPixelArray = 6;
int idjsAmbiIsModeSupported = 7;
int idjsAmbiSetMode = 8;
int idjsAmbiSetPixel = 9;
int idjsAmbiSetPixelArray = 10;
int idjsAudioGetBass = 11;
int idjsAudioGetTreble = 12;
int idjsAudioGetVolume = 13;
int idjsAudioSetBass = 14;
int idjsAudioSetTreble = 15;
int idjsAudioSetVolume = 16;
int jsApiMethodID_Last = 17;


int jsApiNotificationID_Last = 0;

char *jsApiIpcVersion = "1.1.201101271055";

