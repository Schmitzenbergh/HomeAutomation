
/*
 * (c) 2010 Koninklijke Philips Electronics N.V., All rights reserved
 * 
 * This source code and any compilation or derivative thereof is the
 * proprietary information of Koninklijke Philips Electronics N.V. and is
 * confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Koninklijke Philips Electronics N.V.
 */


#if !defined(_PLFAPISRC_TYPES_H_)
#define _PLFAPISRC_TYPES_H_
/*
*   The following types are needed by the prototypes
*   Bool
*   FResult
*   Nat32
*   tmPlfInstPreset_Destination_t
*   tmPlfInstPreset_DestinationType_t
*   tmPlfInstPreset_Source_t
*   tmPlfInstPreset_SourceType_t
*/
#include "./type/infraglobals.dd"
#include "./type/DPlfApiPreset.dd"


#ifndef JSLIB_API
#ifdef WIN32
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the JSLIB_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// JSLIB_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef JSLIB_EXPORTS
#define JSLIB_API __declspec(dllexport)
#else
#define JSLIB_API __declspec(dllimport)
#endif
#else
#define JSLIB_API
#endif
#endif

#endif /* _PLFAPISRC_TYPES_H_ */

