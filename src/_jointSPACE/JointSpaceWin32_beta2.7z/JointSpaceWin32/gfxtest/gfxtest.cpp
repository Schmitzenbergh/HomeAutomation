extern "C" {
#include <directfb.h>
//#include <divine.h>
//#include <fusiondale.h>
//#include <direct/thread.h>
//#include <voodoo/play.h>
//#include <jslibrc_client.h>
}

#ifdef WIN32
#include <time.h>
void sleep(unsigned int mseconds)
{
    clock_t goal = mseconds*1000 + clock();
    while (goal > clock());
}
#endif

/**************************************
* Local macros/typedef
**************************************/
#define DFBCHECK(x) x
//#define DFBCHECK(x,...)                           \
//do {                                             \
//  DFBResult err;                                 \
//  err = x;                                       \
//  if (err != DFB_OK) {                           \
//    printf ("Fail!! err!=DFB_OK");               \
//    DirectFBError (#x, err);                     \
//  }                                              \
//} while(0);



/***************************************
* Local data
***************************************/
static IDirectFB             *dfb = NULL;
static IDirectFBDisplayLayer *layer; 
static DFBWindowDescription  wdesc; 
static IDirectFBWindow       *gwindow; 
static IDirectFBSurface      *gsurface; 
static unsigned short        PixelBuffer[ 1280*720 ]; 
static DFBRectangle          rect; 

int main (int argc, char *argv[])
{
//	int i;
//	char filename[256];

//	mem_Init();
	
	/* DirectFB init */ 
	DFBCHECK(DirectFBInit( &argc, &argv )); 

//	argc--;
//	i = 1;
//	while(argc>0)
	{
//		printf("Index:%d, file:%s\n", i, argv[i]);
//		strcpy(filename, argv[i]);

		DFBCHECK(DirectFBCreate( &dfb )); 
		/* Obtain the layer */ 
		DFBCHECK(dfb->GetDisplayLayer(dfb, DLID_PRIMARY, &layer)); 
		/* Setup the Graphical window */ 
		wdesc.flags = (DFBWindowDescriptionFlags)( DWDESC_WIDTH | DWDESC_HEIGHT | DWDESC_OPTIONS | DWDESC_PIXELFORMAT | DWDESC_STACKING ); 
		wdesc.width = 1280; 
		wdesc.height = 720; 
		wdesc.pixelformat = DSPF_RGB16; // DSPF_ARGB4444 or DSPF_ARGB wdesc.stacking = DWSC_MIDDLE; wdesc.options = DWOP_NONE;
		DFBCHECK(layer->CreateWindow(layer, &wdesc, &gwindow)); 
		DFBCHECK(gwindow->GetSurface(gwindow, &gsurface)); 
		DFBCHECK(gsurface->Clear(gsurface, 0xff,0x00,0x00, 0x00)); //R,G,B,A 
		DFBCHECK(gwindow->SetOpacity(gwindow, 0xff )); 
		DFBCHECK(gwindow->RequestFocus( gwindow )); 
		DFBCHECK(gsurface->Flip( gsurface, NULL, DSFLIP_NONE )); 
		
		sleep(2);
		rect.x = 0; rect.y = 0; rect.w = 1280; rect.h = 720; 
//		jpg_PlaySync(filename, GUIPFM_RGB565, 1280, 720, 1280*2, PixelBuffer, 0);
		// write local pixel buffer (e,g, JPEG decoded data) 
		DFBCHECK(gsurface->Write( gsurface , &rect , (void *)PixelBuffer /* image buffer pointer */ , ( 1280 * 2 ) /* stride */ )); 
		DFBCHECK(gsurface->Flip( gsurface, NULL, DSFLIP_NONE )); 
		sleep(2);

		// to remove GFX content from TV 
		if (dfb) 
		{ 
			DFBCHECK(dfb->Release( dfb ) );
		}
		printf("Removed\n");

//		argc--;
//		i++;
	}

	return(0);
}

