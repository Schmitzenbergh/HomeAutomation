//
//  main.m
//  HueQuickStartApp
//
//  Created by johnnybeek on 06/07/17.
//  Copyright © 2017 Philips Lighting B.V. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PHAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PHAppDelegate class]));
    }
}
