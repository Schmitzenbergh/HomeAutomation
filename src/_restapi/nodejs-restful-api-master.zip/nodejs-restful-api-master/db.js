var mongoose = require('mongoose');
mongoose.connect('mongodb://yourMongoDBURIGoesHere');