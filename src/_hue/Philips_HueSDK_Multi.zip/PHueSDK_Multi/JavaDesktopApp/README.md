Java-DesktopApp
===============

A sample Java/Swing Desktop App using the platform independent Java/Android SDK
