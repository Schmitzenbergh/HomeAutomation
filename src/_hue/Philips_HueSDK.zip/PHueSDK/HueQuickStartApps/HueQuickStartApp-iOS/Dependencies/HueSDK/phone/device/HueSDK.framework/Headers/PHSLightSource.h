/*******************************************************************************
 Copyright (C) 2017 Philips Lighting Holding B.V.
 All Rights Reserved.
 ********************************************************************************/

#import "PHSLightPoint.h"
#import "PHSCompoundLight.h"

@interface PHSLightSource : PHSCompoundLight

@end
