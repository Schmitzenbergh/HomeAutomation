/*******************************************************************************
 Copyright (C) 2017 Philips Lighting Holding B.V.
 All Rights Reserved.
 ********************************************************************************/

typedef NS_ENUM(NSInteger, PHSKnowledgeBaseType) {
    PHSKnowledgeBaseTypeLights        = 0,
    PHSKnowledgeBaseTypeImage         = 1,
    PHSKnowledgeBaseTypeManufacturers = 2
};
