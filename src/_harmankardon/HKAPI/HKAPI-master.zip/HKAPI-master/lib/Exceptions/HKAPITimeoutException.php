<?php

namespace HKAPI\Exceptions;


class HKAPITimeoutException extends HKAPIBaseException
{
}