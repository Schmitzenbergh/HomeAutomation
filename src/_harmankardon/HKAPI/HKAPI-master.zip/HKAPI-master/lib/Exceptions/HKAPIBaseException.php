<?php

namespace HKAPI\Exceptions;


abstract class HKAPIBaseException extends \Exception
{
}