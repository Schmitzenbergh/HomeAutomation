<?php

namespace HKAPI\Exceptions;


class HKAPISocketException extends HKAPIBaseException
{
}