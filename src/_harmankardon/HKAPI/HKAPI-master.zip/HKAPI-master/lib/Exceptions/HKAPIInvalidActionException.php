<?php

namespace HKAPI\Exceptions;


class HKAPIInvalidActionException extends HKAPIBaseException
{
}