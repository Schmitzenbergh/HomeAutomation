<?php

namespace HKAPI\Exceptions;


class HKAPIInvalidZoneException extends HKAPIBaseException
{
}